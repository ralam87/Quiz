//main file to link all files together. 
showQuestion(counter);