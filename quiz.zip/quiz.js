//keeps track of current score
//also current question

var currentScore = 0;
var question = document.getElementById("question")

var choice1 = document.getElementById("choice0");
var choice2 = document.getElementById("choice1");

var guess0 = document.getElementById("guess0");
var guess1 = document.getElementById("guess1");

var questionOf = document.getElementById("progress");

var counter = 1;


